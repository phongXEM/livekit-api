import "dotenv/config";
import express from "express";
import cors from "cors";
import { AccessToken } from "livekit-server-sdk";

const app = express();
app.use(cors());
app.use(express.json());

const apiKey = process.env.LIVEKIT_API_KEY;
const apiSecret = process.env.LIVEKIT_API_SECRET;

app.post("/token", async (req, res) => {
  try {
    const { roomName, identity, name } = req.body;

    if (!roomName || !identity) {
      return res.status(400).json({ error: "roomName and identity are required" });
    }

    const at = new AccessToken(apiKey, apiSecret, {
      identity,
      name: name || identity,
      ttl: "1h",
    });

    at.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: true,
      canSubscribe: true,
    });

    const jwt = await at.toJwt();   // <-- QUAN TRỌNG
    return res.json({ token: jwt });
  } catch (e) {
    console.error("token error:", e);
    return res.status(500).json({ error: "failed to generate token" });
  }
});

app.listen(3000, () => console.log("Token server on :3000"));
